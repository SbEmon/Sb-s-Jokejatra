<?php
date_default_timezone_set('Asia/Dhaka');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = strip_tags($_POST['name']);
    $email = strip_tags($_POST['email']);
    $message = strip_tags($_POST['message']);
    $time = date("Y-m-d H:i:s");

    $entry = "সময়: $time\nনাম: $name\nইমেইল: $email\nবার্তা: $message\n--------------------------\n";

    file_put_contents("messages.txt", $entry, FILE_APPEND | LOCK_EX);

    echo "<script>alert('আপনার বার্তা সফলভাবে পাঠানো হয়েছে!'); window.location.href='contactwithme.html';</script>";
}
?>
