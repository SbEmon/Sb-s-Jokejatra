<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);
    $time = date("Y-m-d H:i:s");

    // ফাইল সেভ
    $entry = "সময়: $time\nনাম: $name\nইমেইল: $email\nবার্তা: $message\n--------------------------\n";
    file_put_contents("messages.txt", $entry, FILE_APPEND);

    // === SMS পাঠানোর অংশ ===
    $sms_message = "নতুন বার্তা: $name বলেছে - $message";
    $receiver_number = "8801615251395"; // এখানে তোমার মোবাইল নাম্বার বসাও (বাংলাদেশ কোড সহ)
    
    $api_key = "3ho663ayuNu0xl7i27LP";
    $sender_id = "03590740020";
    $sms_api_url = "http://bulksmsbd.net/api/smsapi?api_key=$api_key&type=text&number=$receiver_number&senderid=$sender_id&message=" . urlencode($sms_message);

    file_get_contents($sms_api_url); // API কল
    // =======================

    header("Location: contactwithme.html");
    exit;
}
?>
